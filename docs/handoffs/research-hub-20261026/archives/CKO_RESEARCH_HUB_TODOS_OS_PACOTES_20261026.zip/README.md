# BACKUP COMPLETO DOS PACOTES LOCAIS DE PESQUISA — 2026-10-26

Inclui 19 arquivos ZIP (conteúdo byte-a-byte), com manifest SHA-256. Há 1 duplicata(s) de conteúdo, preservada(s) pelo nome.

**GitHub existente:** https://github.com/IndiciumFIN/dev-chatgpt-workspace/tree/backup/research-hub-complete-20261026
**Commit do backup do código:** bcf1791e6ff7ca1028d354e79285310de0906ace

**Importante:** os ZIPs deste pacote ainda não estão no GitHub; a conexão GitHub desta sessão grava texto e blobs informados, mas não oferece ingestão direta do arquivo sandbox. É necessário enviar esse ZIP ao repositório ou usar o roteiro em `ENVIAR-AO-GITHUB.sh` num checkout autenticado. Não há aprovação automática do Kernel.

**Restauração:** extraia os ZIPs da pasta `pacotes/`. Confirme seus SHA-256 contra `MANIFEST.json`. Não execute scripts sem revisar escopo e governança.
