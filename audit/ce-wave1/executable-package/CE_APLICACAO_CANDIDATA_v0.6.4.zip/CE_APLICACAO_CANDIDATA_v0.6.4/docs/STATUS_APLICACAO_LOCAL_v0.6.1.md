# Aplicação local candidata — v0.6.1

**Destino previsto:** IndiciumFIN/dev-chatgpt-workspace, branch `integration/structural-overlay-20261101`.
**Baseline remoto conferido:** `081c61ac6c6ea674934d1cad3c310e96476fc9a1`.

## Estado

- Os 21 arquivos do patch v0.6.0 foram materializados em uma **árvore candidata isolada**, sem sobrepor checkout de repositório Git.
- Corrigidos os imports relativos do Kernel legado para extensões `.ts` explicitamente, adequadas ao executor Node 22 experimental-strip-types e `allowImportingTsExtensions=true` da configuração TypeScript do projeto.
- Os 7 blobs originais a substituir foram confirmados idênticos ao baseline GitHub.
- O instalador preserva invariantes de branch, ancestry, alvo limpo e SHA de blob, faz backup externo e **não** executa push, commit, merge ou deploy.
- Testes em árvore local: 2 de Ed25519, 5 de fail-closed (com dependências de compliance reduzidas apenas para teste), 4 de readiness = 11 PASS. Esses testes **não** são CI completo nem prova de homologação.
- O pacote precisa ser aplicado no checkout real com WO admitida verificada, depois executar `npm ci`, `npm run typecheck`, `npm test`, `npm run build:spa` e workflows do GitHub.
- Os 3 registros de Curiosidades MEM continuam externos: o reconciliador busca blobs originais imutáveis e valida HOLD, sem fabricar dados.
- Evidências de governança e promoção permanecem em **HOLD**. Nenhuma aprovação de Kernel foi gerada.

## Limitação de execução

O ambiente de trabalho não consegue acessar `github.com` por Git (`Could not resolve host`). A integração GitHub conectada confirmou o HEAD e os hashes, mas a WO não foi apresentada nem autenticada. Por isso não foi executada uma escrita remota. A pasta atual é **overlay proposto**, não clone íntegro do repositório.
