#!/usr/bin/env bash
set -euo pipefail
# Execute em um checkout LOCAL autenticado do repositorio com permissao de escrita.
# Este script NAO faz merge, deploy, nem altera main.
if [[ ! -d .git ]]; then echo 'ERRO: execute na raiz de um checkout Git valido' >&2; exit 1; fi
if [[ "$(git remote get-url origin)" != *"IndiciumFIN/dev-chatgpt-workspace"* ]]; then echo 'ERRO: repositorio divergente' >&2; exit 1; fi
if [[ -n "$(git status --porcelain)" ]]; then echo 'ERRO: arvore de trabalho alterada' >&2; exit 1; fi
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
git fetch origin backup/research-hub-complete-20261026
git switch backup/research-hub-complete-20261026 2>/dev/null || git switch -c backup/research-hub-complete-20261026 --track origin/backup/research-hub-complete-20261026
TARGET='docs/handoffs/research-hub-20261026/offline-archives'
mkdir -p "$TARGET"
cp "$HERE/pacotes/"*.zip "$TARGET/"
cp "$HERE/MANIFEST.json" "$TARGET/ARCHIVE-MANIFEST.json"
git add "$TARGET"
git diff --cached --stat
printf '%s\n' 'Conferir o diff antes de prosseguir. Este backup e somente arquivo; nao integra codigo candidato.'
# Commit e push so ocorrem com aprovacao explicita no terminal desta maquina
read -r -p 'Confirmar commit e push de backup (digite SIM): ' answer
if [[ "$answer" != 'SIM' ]]; then echo 'Pendente, nenhum push executado'; exit 0; fi
git commit -m 'archive(research): preservar pacotes incrementais locais e hashes [HOLD]'
git push -u origin backup/research-hub-complete-20261026
